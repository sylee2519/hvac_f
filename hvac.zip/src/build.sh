cd ../../build/
make clean
make
