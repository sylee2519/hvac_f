export PKG_CONFIG_PATH=$PKG_CONFIG_PATH:/gpfs/alpine/stf008/proj-shared/HVAC/ofi-install/lib/pkgconfig
export PKG_CONFIG_PATH=$PKG_CONFIG_PATH:/gpfs/alpine/stf008/proj-shared/HVAC/mercury-install/lib/pkgconfig
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/gpfs/alpine/stf008/proj-shared/HVAC/ofi-install/lib/
